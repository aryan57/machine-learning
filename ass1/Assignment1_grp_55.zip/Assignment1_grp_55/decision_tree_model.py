# This file contains the basic structure of the model
import helper_funcs
idx = 0


# The main data structure node to implement the tree
class node:

    attr_val = {'buying': ['vhigh', 'high', 'med', 'low'],
                     'maint': ['vhigh', 'high', 'med', 'low'],
                     'doors': ['2', '3', '4', '5more'],
                     'persons': ['2', '4', 'more'],
                     'lug_boot': ['small', 'med', 'big'],
                     'safety': ['low', 'med', 'high']
                     }
    def __init__(self, attr, data, target, is_leaf):
        global idx
        self.idx = idx
        idx += 1
        self.children = {}
        self.attr = attr
        self.data = data
        self.target = target
        self.is_leaf = is_leaf

    def prune_node(self):
      self.is_leaf = True

    def restore(self):
      self.is_leaf = False

# builds the tree recursively given a depth limit and dataset using a attribute selector(gini/entropy)
def build(data, attr_list, cur_h, max_h, glob_max, attribute_selector):
    n = len(data)

    if n == 0:
        return node(None, None, glob_max, True)

    # find the target value with most frequency
    target_dict = {'unacc':  [],
                   'acc':    [],
                   'good':   [],
                   'vgood':  []
                   }
    for item in data:
        target_dict[item['target']].append(item)
    majority_target = 'unacc'
    for i in target_dict:
        if len(target_dict[i]) > len(target_dict[majority_target]):
            majority_target = i
    if len(attr_list) == 0:

        return node(None, None, majority_target, True)

    if len(target_dict[majority_target]) == n or cur_h >= max_h:
        return node(None, None, majority_target, True)

    best_attr, best_split = attribute_selector(data, attr_list)

    head = node(best_attr, data, majority_target, False)
    for val in head.attr_val[best_attr]:
        new_attr_list = []
        for i in attr_list:
            if i != best_attr:
                new_attr_list.append(i)
        if val in best_split:
          head.children[val] = build(best_split[val], new_attr_list, cur_h+1, max_h, majority_target, attribute_selector)
        else:
          head.children[val] = build([], new_attr_list, cur_h+1, max_h, majority_target, attribute_selector)

    return head

# returns the prediction on sample example
def predict(cur_node, item):
  if cur_node.is_leaf:
    return cur_node.target

  return predict(cur_node.children[item[cur_node.attr]], item)

# caluclates the percentage accuracy over a test set
def get_accuracy(tree_root, X_test):
  correct = 0
  n = len(X_test)
  for item in X_test:
    pred = predict(tree_root, item)

    correct += (pred==item['target'])
  
  accuracy = (correct/n)*100
  return accuracy

# Counts the nodes in a tree recursively
def count_nodes(cur_node):
  if cur_node.is_leaf:
    return 1
  val = 1
  for i in cur_node.children:
    val += count_nodes(cur_node.children[i])
  return val

# deletes the children of node that is permanently pruned
def clean_tree(cur_node):
  if cur_node.is_leaf:
    cur_node.children = {}
  else:
      for i in cur_node.children:
        clean_tree(cur_node.children[i])

# goes through all the nodes and prunes them and returns the best accuracy
def prune_tree(root, cur_node, X_test):
  if cur_node.is_leaf:
    return cur_node.idx, 0
  
  cur_node.prune_node()
  best_acc = get_accuracy(root, X_test)
  best_id = cur_node.idx
  cur_node.restore()
  # print("cur id ", best_id)
  for i in cur_node.children:
    id, accuracy = prune_tree(root, cur_node.children[i], X_test)
    if accuracy >= best_acc:
      best_acc = accuracy
      best_id = id
  
  return best_id, best_acc

# deletes the children of a particular node
def delete_children(cur_node, id):
  if cur_node.idx == id:
    cur_node.prune_node()
    cur_node.children = {}
    return
  if cur_node.is_leaf:
    return 
  for i in cur_node.children:
    delete_children(cur_node.children[i], id)

# runs the reduced error pruning algorithm
def prune(root, X_test):
  prev_acc = get_accuracy(root, X_test)
  while True:
    print("pruning////////////")
    id, accuracy = prune_tree(root, root, X_test)
    if accuracy > prev_acc:
      print("Node id pruned = ", id)
      print("Accuracy improved to = ", accuracy)
      delete_children(root, id)
      prev_acc = accuracy
    else:
      break
  print("No More improvement possible")
    



